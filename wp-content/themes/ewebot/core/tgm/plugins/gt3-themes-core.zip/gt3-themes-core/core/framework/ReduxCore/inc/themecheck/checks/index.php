<?php
// Silence is golden
